#include "Animal.h"

Animal::Animal(string food) {
	this->food=food;
}
