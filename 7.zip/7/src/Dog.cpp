#include "Dog.h"

Dog::Dog() : Animal::Animal("����"){}

void Dog::Eat() {
	cout << food << endl;
}
