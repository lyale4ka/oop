#include "Parrot.h"

Parrot::Parrot() : Animal::Animal("�����") {}

void Parrot::Eat() {
	cout << food << endl;
}
