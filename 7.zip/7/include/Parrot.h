#ifndef PARROT_H
#define PARROT_H
#include "Animal.h"

class Parrot : public Animal {
public:
	Parrot();
	void Eat() override;
};

#endif // PARROT_H
