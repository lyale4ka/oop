#ifndef CAT_H
#define CAT_H
#include "Animal.h"

class Cat:Animal {
public:
	Cat();
	void Eat() override;
};

#endif // CAT_H
