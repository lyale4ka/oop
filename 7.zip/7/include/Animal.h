#ifndef ANIMAL_H
#define ANIMAL_H
#include <string>
#include <iostream>

using namespace std;

class Animal {
public:
	Animal(string);
	virtual void Eat() = 0;
protected:
	string food;
};
#endif // ANIMAL_H
